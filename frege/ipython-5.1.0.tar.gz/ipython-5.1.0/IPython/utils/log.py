from __future__ import absolute_import

from warnings import warn

warn("IPython.utils.log has moved to traitlets.log")

from traitlets.log import *
