.. _issues_list_5:

Issues closed in the 5.x development cycle
==========================================

Issues closed in 5.1
--------------------

GitHub stats for 2016/07/08 - 2016/08/13 (tag: 5.0.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 33 issues and merged 43 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A5.1+>`__

The following 17 authors contributed 129 commits.

* Antony Lee
* Benjamin Ragan-Kelley
* Carol Willing
* Danilo J. S. Bellini
* 小明 (`dongweiming <https://github.com/dongweiming>`__)
* Fernando Perez
* Gavin Cooper
* Gil Forsyth
* Jacob Niehus
* Julian Kuhlmann
* Matthias Bussonnier
* Michael Pacer
* Nik Nyby
* Pavol Juhas
* Luke Deen Taylor
* Thomas Kluyver
* Tamir Bahar


Issues closed in 5.0
--------------------

GitHub stats for 2016/07/05 - 2016/07/07 (tag: 5.0.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 95 issues and merged 191 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A5.0+>`__

The following 27 authors contributed 229 commits.

* Adam Greenhall
* Adrian
* Antony Lee
* Benjamin Ragan-Kelley
* Carlos Cordoba
* Carol Willing
* Chris
* Craig Citro
* Dmitry Zotikov
* Fernando Perez
* Gil Forsyth
* Jason Grout
* Jonathan Frederic
* Jonathan Slenders
* Justin Zymbaluk
* Kelly Liu
* klonuo
* Matthias Bussonnier
* nvdv
* Pavol Juhas
* Pierre Gerold
* sukisuki
* Sylvain Corlay
* Thomas A Caswell
* Thomas Kluyver
* Trevor Bekolay
* Yuri Numerov
